;(function($){
	"use strict";

	$(document).ready(function() {

		// Your JS & jQuery Code here

	});// end of document ready

})(jQuery);